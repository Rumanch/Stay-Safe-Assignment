using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    public GameObject gameOverPanel;

    private bool isGameOver = false; // Added to prevent multiple activations

    void Update()
    {
        // Check if the player no longer exists and game over has not been triggered yet
        if (GameObject.FindGameObjectWithTag("Player") == null && !isGameOver)
        {
            gameOverPanel.SetActive(true);
            isGameOver = true; // Set game over flag to true
        }
    }

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}

