using UnityEngine;

public class BackgroundMusicManager : MonoBehaviour
{
    private AudioSource audioSource;

    void Start()
    {
        // Get the AudioSource component
        audioSource = GetComponent<AudioSource>();
        audioSource.Play(); // Start the background music
    }

    public void SlowDownMusic()
    {
        if (audioSource != null)
        {
            // Slow down the music by reducing the pitch
            audioSource.pitch = 0.5f; // Adjust this value for the desired slowdown
        }
    }

    public void ResetMusicSpeed()
    {
        if (audioSource != null)
        {
            // Reset the pitch to normal speed
            audioSource.pitch = 1f;
        }
    }
}
